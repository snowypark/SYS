#include <stdio.h>

#define PAGE_SIZE 10  // 한 페이지에 출력할 라인 수

void more(FILE* file) {
    int line_count = 0;  // 현재까지 출력한 라인 수
    char buffer[256];   // 한 줄씩 읽어올 버퍼

    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        printf("%s", buffer);
        line_count++;

        if (line_count == PAGE_SIZE) {
            // 한 페이지를 출력했으면 추가 입력 대기
            printf("-- More --");
            getchar();  // 사용자 입력 대기

            // 출력한 라인 수와 버퍼를 초기화
            line_count = 0;
            printf("\033[1A\033[2K\033[1G");  // 현재 라인 삭제
        }
    }
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    FILE* file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("Failed to open file.\n");
        return 1;
    }

    more(file);

    fclose(file);
    return 0;
}

